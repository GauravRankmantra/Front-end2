import React from 'react'

const Purchase = () => {
  return (
    <div className='m-24 text-6xl font-bold text-center text-white'>
      Plans page 
    </div>
  )
}

export default Purchase
